﻿using ConsoleTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGradingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            int no = 1, student_A = 0, student_pass = 0, student_notpass = 0;
            float total_mark = 0, num;
            bool cek = false;
            SortedDictionary<string, float> dic = new SortedDictionary<string, float>();

            while (true)
            {
                system();
                string menu = Console.ReadLine();

                if (menu == "1")
                {
                    while (true)
                    {
                        Add_Student();
                        Console.WriteLine("Enter Student Name: \t  Back (press 1 to back)");
                        string name = Console.ReadLine();
                        if (name == "")
                        {
                            Console.WriteLine("\nPlease enter a valid student name:");
                            PrintforUser();
                        }
                        else if (name == "1")
                        {
                            Console.Clear();
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Enter Student Score:");
                            string score = Console.ReadLine();

                            bool check = float.TryParse(score, out num);

                            if (check == false)
                            {
                                OnlyNumber();
                            }
                            else
                            {
                                if (dic.ContainsKey(name) == true)
                                {
                                    Duplicate_Name();
                                }
                                else if (num < 0 || num > 100)
                                {
                                    Console.WriteLine("\nPlease enter the number between 0 to 100.");
                                    PrintforUser();
                                }
                                else
                                {
                                    if (num >= 0 && num <= 100)
                                    {
                                        total_mark += num;
                                        dic.Add(name, num);
                                        Student_Add();
                                        string choice = Console.ReadLine();

                                        if (choice == "2")
                                        {
                                            Console.Clear();
                                            table(dic);
                                            PrintforUser();
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else if (menu == "2")
                {
                    if (dic.Count == 0)
                    {
                        No_record();
                    }
                    else
                    {
                        while (true)
                        {
                            Console.Clear();
                            table(dic);
                            Remove_Student();
                            Console.WriteLine("Enter Student Name: \t  Back (press 1 to back)");
                            string name = Console.ReadLine();

                            if (name == "")
                            {
                                Console.WriteLine("\nPlease enter a valid student name:");
                                PrintforUser();
                            }
                            else if (name == "1")
                            {
                                Console.Clear();
                                break;
                            }
                            else
                            {
                                foreach (var student in dic)
                                {
                                    if (student.Key == name)
                                    {
                                        cek = true;
                                        float score = student.Value;
                                        total_mark -= score; 
                                    }
                                }
                                if (cek==true)
                                {
                                    cek = false;
                                    dic.Remove(name);
                                    Student_Remove();
                                    string choice = Console.ReadLine();

                                    if (choice == "2")
                                    {
                                        Console.Clear();
                                        table(dic);
                                        PrintforUser();
                                        break;
                                    }
                                }
                                else
                                {
                                    No_record();
                                }
                            }
                        }
                    }
                }
                else if (menu == "3")
                {
                    if (dic.Count == 0)
                    {
                        No_record();
                    }
                    else
                    {
                        while (true)
                        {
                            Student_UpdateMenu();
                            table(dic);
                            Console.WriteLine("Enter Student Name: \t  Back (press 1 to back)");
                            string name = Console.ReadLine();

                            if (name == "")
                            {
                                Console.WriteLine("\nPlease enter a valid student name:");
                                PrintforUser();
                            }
                            else if (name == "1")
                            {
                                Console.Clear();
                                break;
                            }
                            else
                            {
                                foreach (var student in dic)
                                {
                                    if (student.Key == name)
                                    {
                                        cek = true;
                                        float score = student.Value;
                                        total_mark -= score; 
                                    }
                                }
                                if (cek == true)
                                {
                                    dic.Remove(name);
                                    while (true)
                                    {
                                        Console.WriteLine("Enter New Student Name: ");
                                        name = Console.ReadLine();

                                        if (name == "")
                                        {
                                            Console.WriteLine("\nPlease enter a valid student name:");
                                            PrintforUser();
                                        }
                                        else
                                        {
                                            Console.WriteLine("Enter New Student Score:");
                                            bool check = float.TryParse(Console.ReadLine(), out num);

                                            if (check == false)
                                            {
                                                OnlyNumber();
                                            }
                                            else
                                            {
                                                if (dic.ContainsKey(name) == true)
                                                {
                                                    Duplicate_Name();
                                                }
                                                else if (num < 0 || num > 100)
                                                {
                                                    Console.WriteLine("\nPlease enter the number between 0 to 100.");
                                                    PrintforUser();
                                                }
                                                else
                                                {
                                                    if (num >= 0 && num <= 100)
                                                    {
                                                        total_mark += num; cek = false;
                                                        dic.Add(name, num);
                                                        Student_Update();
                                                        string choice = Console.ReadLine();

                                                        if (choice == "2")
                                                        {
                                                            Console.Clear();
                                                            table(dic);
                                                            PrintforUser();
                                                            break;
                                                        }
                                                        else
                                                        {
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    No_record();
                                }
                            }
                        }
                    }
                }
                else if (menu == "4")
                {
                    while (true)
                    {
                        student_list();
                        int.TryParse(Console.ReadLine(), out int list);

                        if (list == 1)
                        {
                            Console.Clear();
                            table(dic); other_table();
                            PrintforUser();
                        }
                        else if (list == 2)
                        {
                            Console.Clear();
                            table(dic.Reverse()); other_table();
                            PrintforUser();
                        }
                        else if (list == 3)
                        {
                            Console.Clear();
                            table(dic.OrderByDescending(e => e.Value).Reverse()); other_table();
                            PrintforUser();
                        }
                        else if (list == 4)
                        {
                            Console.Clear();
                            table(dic.OrderByDescending(e => e.Value)); other_table();
                            PrintforUser();
                        }
                        else if (list == 5)
                        {
                            Console.Clear();
                            break;
                        }
                        else
                        {
                            Invalid_Option();
                        }
                    }
                }
                else if (menu == "5")
                {
                    if (dic.Count == 0)
                    {
                        No_record();
                    }
                    else
                    {
                        Console.Clear();
                        float highest = dic.ElementAt(0).Value, lowest = dic.ElementAt(0).Value;
                        float A = 80, pass = 50;
                        no = 1;
                        var table = new ConsoleTable("No", "Student Name", "Student Score", "Grade", "Pass or Fail");

                        foreach (var student in dic)
                        {
                            table.AddRow(no, student.Key, student.Value, CalculateGrade(student.Value), Calculate_StudentPass(student.Value));
                            no++;

                            if (student.Value > highest)
                            {
                                highest = student.Value;
                            }
                            if (student.Value < lowest)
                            {
                                lowest = student.Value;
                            }
                            if (student.Value >= A)
                            {
                                student_A++;
                            }
                            if (student.Value >= pass)
                            {
                                student_pass++;
                            }
                            if (student.Value < pass)
                            {
                                student_notpass++;
                            }
                        }
                        table.Options.EnableCount = false;
                        table.Write();

                        Student_DataSummary();
                        Console.WriteLine($"Total Student : {dic.Count} ");
                        Console.WriteLine($"Average Score of the student : {total_mark / dic.Count} ");
                        Console.WriteLine($"Highest Score of the student : {highest} ");
                        Console.WriteLine($"Lowest Score of the student : {lowest}  ");
                        Console.WriteLine($"Student who get A : {student_A} ");
                        Console.WriteLine($"\nPassing Score is 50 ");
                        Console.WriteLine($"---------------------- ");
                        Console.WriteLine($"Student who pass : {student_pass} ");
                        Console.WriteLine($"Student who fail : {student_notpass} ");
                        PrintforUser();
                        student_A = 0;
                        student_pass = 0;
                        student_notpass = 0;
                    }
                }
                else if (menu == "6")
                {
                    System.Environment.Exit(0);
                }
                else
                {
                    Invalid_Option();
                }
            }
        }
        public static void Invalid_Option()
        {
            Console.WriteLine("\nInvalid Option");
            Console.Write("Press Y or any key to continue");
            Console.ReadKey();
            Console.Clear();
        }
        public static void Negative_No()
        {
            Console.WriteLine("\nCan't insert negative number. ");
            Console.Write("Press Y or any key to continue");
            Console.ReadKey();
            Console.Clear();
        }
        public static void system()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("*********************************************************");
            Console.WriteLine("                Student Grading System");
            Console.WriteLine("*********************************************************");
            Console.ResetColor();
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. Remove Student");
            Console.WriteLine("3. Update Student Data");
            Console.WriteLine("4. Student List");
            Console.WriteLine("5. Student Data Summary");
            Console.WriteLine("6. Exit");
            Console.Write("Enter Your Option :");
        }
        public static void student_list()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("********************************************");
            Console.WriteLine("           Student List");
            Console.WriteLine("********************************************");
            Console.ResetColor();
            Console.WriteLine("1. Ascending By Name (A-Z)");
            Console.WriteLine("2. Descending By Name (Z-A)");
            Console.WriteLine("3. Ascending By Score (Low - High)");
            Console.WriteLine("4. Descending By Score (High - Low)");
            Console.WriteLine("5. Back to menu");
            Console.Write("Enter Your Option :");
        }
        public static void Add_Student()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("********************************************");
            Console.WriteLine("               Add Student");
            Console.WriteLine("********************************************");
            Console.ResetColor();
        }
        public static void Remove_Student()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("********************************************");
            Console.WriteLine("               Remove Student");
            Console.WriteLine("********************************************");
            Console.ResetColor();
        }
        public static void OnlyNumber()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter Numbers Only.");
            Console.ResetColor();
            Console.Write("Press Y or any key to continue");
            Console.ReadKey();
            Console.Clear();
        }
        public static void No_record()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("No student record. ");
            Console.ResetColor();
            Console.Write("Press Y or any key to continue");
            Console.ReadKey();
            Console.Clear();
        }
        public static void PrintforUser()
        {
            Console.Write("Press Y or any key to continue");
            Console.ReadKey();
            Console.Clear();
        }
        public static void Duplicate_Name()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nDuplicate student name");
            Console.ResetColor();
            Console.Write("Press Y or any key to continue");
            Console.ReadKey();
            Console.Clear();
        }
        public static void Student_Add()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nStudent Added Sucessful");
            Console.ResetColor();
            Console.WriteLine("\nDo you want to continue? ");
            Console.WriteLine("1. Yes\t2. No");
        }
        public static void Student_Update()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nStudent Update Sucessful");
            Console.ResetColor();
            Console.WriteLine("\nDo you want to continue? ");
            Console.WriteLine("1. Yes\t2. No");
        }
        public static void Student_UpdateMenu()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("********************************************");
            Console.WriteLine("           Update Student Data");
            Console.WriteLine("********************************************");
            Console.ResetColor();
        }
        
        public static void Student_DataSummary()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("********************************************");
            Console.WriteLine("           Summary of the student");
            Console.WriteLine("********************************************");
            Console.ResetColor();
        }
        public static void Student_Remove()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nStudent Remove Sucessful");
            Console.ResetColor();
            Console.WriteLine("\nDo you want to continue? ");
            Console.WriteLine("1. Yes\t2. No");
        }
        public static string CalculateGrade(double score)
        {
            string mark = "-";
            if (score >= 80 && score <= 100)
            {
                mark = "A";
            }
            else if (score >= 70 && score < 80)
            {
                mark = "B";
            }
            else if (score >= 60 && score < 70)
            {
                mark = "C";
            }
            else if (score >= 50 && score < 60)
            {
                mark = "D";
            }
            else if (score >= 40 && score < 50)
            {
                mark = "E";
            }
            else if (score >= 0 && score < 40)
            {
                mark = "F";
            }
            else
            {
                mark = "-";
            }
            return mark;
        }
        public static string Calculate_StudentPass(double score)
        {
            string mark = "-";
            if (score >= 50 && score <= 100)
            {
                mark = "Pass";
            }
            else if (score >= 0 && score < 50)
            {
                mark = "Fail";
            }
            else
            {
                mark = "-";
            }
            return mark;
        }
        public static void table(IEnumerable<KeyValuePair<string, float>> dic)
        {
            var table = new ConsoleTable("No", "Student Name", "Student Score", "Grade", "Pass or Fail");
            int no = 1;
            foreach (var student in dic)
            {
                table.AddRow(no, student.Key, student.Value, CalculateGrade(student.Value), Calculate_StudentPass(student.Value));
                no++;
            }
            table.Options.EnableCount = false;
            table.Write();
        }
        public static void other_table()
        {
            char[] alphabet = { 'A', 'B', 'C', 'D', 'E', 'F' };
            String[] score = { "80 - 100", "70 - 79", "60 - 69", "50 - 59", "40 - 49", "0 - 39" };
            var table = new ConsoleTable("Grade", "Marks");
            for (int i = 0; i < 6; i++)
            {
                table.AddRow(alphabet[i], score[i]);
            }
            table.Options.EnableCount = false;
            table.Write();
        }
    }
}
